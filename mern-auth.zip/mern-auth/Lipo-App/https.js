const https = require("https");
var express = require("express");
var app = express();
var path = require('fs');

app.use(express.static('Public'))

https.createServer({
    key: fs.readFileSync('server.key'),
    cert: fs.readFileSync('server.cert')}, app).listen(8080, ()=> {
        console.log('Listening...')
})