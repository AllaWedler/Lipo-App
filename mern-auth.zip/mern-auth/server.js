const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const app = express();

// Bodyparser middleware
// This will be used to parse form, when it will be submitted to the server (when button with the type submit was pressed)
// create application/x-www-form-urlencoded parser
var urlencodedParser = bodyParser.urlencoded({ extended: false })

// create application/json parser
var jsonParser = bodyParser.json();

//app.set("env", "production"); // this is how you prevent public stack traces (news to me 😉)


//app.use(express.json());

app.use(express.static('Public'));

//Set up default mongoose connection
const dbURI = require("./config/keys").mongoURI;
mongoose.connect(dbURI, { useNewUrlParser: true });

//Get the default connection
var db = mongoose.connection;

//Bind connection to error event (to get notification of connection errors)
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.on('open', console.error.bind(console, 'MongoDB connection successfully opened!'));

//
//require('./config/models/validation/passport.js');
//

// Load User model
require('./models/User');
const User = mongoose.model('users');

// set the view engine to ejs
app.set('view engine', 'ejs');

// use res.render to load up an ejs view file


// Seite0 page 
app.get('/', function(req, res) {
    res.render('pages/Seite0');
});


// Seite1 page 
app.get('/Seite1', function(req, res) {
    res.render('pages/Seite1');
});


// Seite4 page 
app.get('/Seite4', function(req, res) {
    res.render('pages/Seite4');
});

app.post('/saveuser', urlencodedParser, function(req, res) {
   console.log(req.body); 
   
   console.log(req.headers); 
   /*
   const newUser = {
       firstname     : req.body.name,
       lastname : req.body.lastname,
       email    : req.body.email,
       password : req.body.password
       // you can define more fields here, but they're not currently available in User.js Model definition...
   };*/
      const newUser = {
       firstname     : 'John',
       lastname : 'Doe',
       email    : 'jdoe@gmail.com',
       password : 'topsecret'
       // you can define more fields here, but they're not currently available in User.js Model definition...
   };
   
   
   new User(newUser)
   .save()
   .then(user => {
      res.render('pages/Seite2');
   });
   
   //res.render('pages/Seite2');
});

// Seite6 page 
app.get('/Seite6', function(req, res) {
    res.render('pages/Seite6');
});


// Seite2 page 
app.get('/Seite2', function(req, res) {
    res.render('pages/Seite2');
});

// Seite3 page 
app.get('/Seite3', function(req, res) {
    res.render('pages/Seite3');
});


// Seite8 page 
app.get('/Seite8', function(req, res) {
    res.render('pages/Seite8', {db : db});
});    
    

// Seite5 page 
app.get('/Seite5', function(req, res) {
    res.render('pages/Seite5');
});


// Seite7 page 
app.get('/Seite7', function(req, res) {
    res.render('pages/Seite7');
});

// Seite9 page 
app.get('/Seite9', function(req, res) {
    res.render('pages/Seite9');
});

const port = process.env.PORT || 8080; // process.env.port is Heroku's port if you choose to deploy the app there
app.listen(port, () => console.log(`Server up and running on port ${port} !`));
