module.exports = {
  //mongoURI: "mongodb://Selcan:oktay@cluster0-d3msm.mongodb.net/test",
  mongoURI : "mongodb://localhost:27017/lipodb",
  secretOrKey: "secret"
};